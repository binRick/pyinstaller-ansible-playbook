#ifndef BOOTLOADER_EXTRACT_H
#define BOOTLOADER_EXTRACT_H

void extract_archive(const char *dest_path);

#endif /* BOOTLOADER_EXTRACT_H */
