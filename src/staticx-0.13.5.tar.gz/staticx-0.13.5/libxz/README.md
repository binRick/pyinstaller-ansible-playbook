These files are from "XZ Embedded":

URL:      https://tukaani.org/xz/embedded.html
Date:     2017-04-07
Revision: 79b68de5657beecfad575578a7181cf6fca869cb

"XZ Embedded has been put into the public domain, thus you can do whatever you
 want with it. All the files in XZ Embedded have been written by Lasse Collin,
 but some files are heavily based on public domain code written by Igor Pavlov."
